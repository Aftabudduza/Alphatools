﻿using System;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Web;

//using PdfSharp.Pdf.Content.Objects;

/// <summary>
/// Summary description for appGlobal
/// </summary>
public class AppGlobal
{
    public string WebsiteId = "29";
    //public AppGlobal()
    //{
    //    //
    //    // TODO: Add constructor logic here
        
    //    //
    //}    

    public static string Connectionstring
    {
        get
        {
            try
            {
                return Convert.ToString(ConfigurationManager.ConnectionStrings["SQLDB"].ConnectionString);
            }
            catch (Exception)
            {
                // ignored
            }
            return "";
        }
    }

    public static string GetMD5Hash(string password)
    {
        UTF8Encoding encoder = new UTF8Encoding();
        byte[] hashedpwd;
        MD5CryptoServiceProvider MD5Hasher = new MD5CryptoServiceProvider();
        hashedpwd = MD5Hasher.ComputeHash(encoder.GetBytes(password));


        string hashAsString;
        hashAsString = HttpUtility.UrlEncode(Convert.ToBase64String(hashedpwd));
        return hashAsString;
    }

    public static void processUrl(HttpContext context)
    {
        string path = context.Request.Path;       
        string nbase = "~";
        string stemp = "";
        string[] aArray = null;


        if (path.Contains("http://65.51.46.135/"))
        {
            path = path.Replace("http://65.51.46.135/", "http://65.51.46.135/");
        }

        try
        {
            string old_path = HttpContext.Current.Request.Url.ToString().ToLower();
            if (old_path.Contains("http://65.51.46.135/"))
            {
                old_path = old_path.Replace("http://65.51.46.135/", "http://65.51.46.135/");
            }

            if (old_path.Contains("section.aspx"))
            {
                stemp = "";
                aArray = null;
                aArray = old_path.Split('=');
                if ((aArray != null) & aArray.Length > 1)
                {
                    if ((aArray[1] != null))
                    {
                        stemp = aArray[1].ToString().Trim();
                        if (stemp.Length > 0)
                        {
                            string surl = "http://65.51.46.135/pages/productpages.aspx?sectionid=" + stemp;
                            context.Response.Status = "301 Moved Permanently";
                            context.Response.AddHeader("Location", surl);
                            context.Response.End();
                        }
                    }
                }
            }
            else if (old_path.Contains("group.aspx"))
            {
                stemp = "";
                aArray = null;
                aArray = old_path.Split('=');
                if ((aArray != null) & aArray.Length > 1)
                {
                    if ((aArray[1] != null))
                    {
                        stemp = aArray[1].ToString().Trim();
                        if (stemp.Length > 0)
                        {
                            string surl = "http://65.51.46.135/pages/productpages.aspx?GroupId=" + stemp;
                            context.Response.Status = "301 Moved Permanently";
                            context.Response.AddHeader("Location", surl);
                            context.Response.End();
                        }
                    }
                }
            }
            else if (old_path.Contains("product.aspx"))
            {
                stemp = "";
                aArray = null;
                aArray = old_path.Split('=');
                if ((aArray != null) & aArray.Length > 1)
                {
                    if ((aArray[1] != null))
                    {
                        stemp = aArray[1].ToString().Trim();
                        if (stemp.Length > 0)
                        {
                            string surl = "http://65.51.46.135/pages/productdetails.aspx?pagecode=" + stemp;
                            context.Response.Status = "301 Moved Permanently";
                            context.Response.AddHeader("Location", surl);
                            context.Response.End();
                        }
                    }
                }
            }

            else if (old_path.Contains("index.aspx"))
            {
                old_path = "http://65.51.46.135/Default.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }

            else if (old_path.Contains("newproducts.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/NewProducts.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("educationalmaterials.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/EducationalMaterials.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("whatsnew.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/WhatsNew.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("calendar.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Calendar.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("productbulletins.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/ProductBulletins.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("technicallibrary.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Library.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("requestdealerinfo.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/RequestADealerInfo.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("links.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/LinksAndAffiliations.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("about.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/AboutUs.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("contact.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/ContactUs.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("policies.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Policies.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("shopatron.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Shopatron.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("sitemap.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Sitemap.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("Metals.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/IndustrialProducts.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("affiliations.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Affiliations.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("employment.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/Employment.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("productregistration.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/ProductRegistration.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("catalogs.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/ProductCatalogs.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("MCalc.aspx"))
            {
                old_path = "http://65.51.46.135/Pages/MoistureCalculator.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("admin/Login.aspx"))
            {
                old_path = "http://65.51.46.135/pages/account/Login.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }
            else if (old_path.Contains("Members/Default.aspx"))
            {
                old_path = "http://65.51.46.135/admin/Files/Members/Default.aspx";
                context.Response.Status = "301 Moved Permanently";
                context.Response.AddHeader("Location", old_path);
                context.Response.End();
            }

            if (path.Length > 0)
            {
                context.RewritePath(path, false);
            }
            else
            {
                context.RewritePath(old_path, false);
            }

        }
        catch (Exception ex)
        {
        }

    }
    
}