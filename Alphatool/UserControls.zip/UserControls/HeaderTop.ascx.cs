﻿using System;
using System.Collections.Generic;
using System.Web.Providers.Entities;
using AlphatoolServices.BO;
using AlphatoolServices.DA;

namespace UserControls
{
    public partial class HeaderTop : System.Web.UI.UserControl
    {
       

       
    }
}
